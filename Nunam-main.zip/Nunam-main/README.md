# Nunam
Nunam assignment solutions.
Task1 can be run in any Python IDE. The project in which this file is present must contain all the excel files. This program generates 3 csv files in the same directory location.
Task2 can be run in any Python IDE with all the CSV files in the same directory. This program generates applies downsampling on the given csv data and generates new downsampled csv files.
Task4 is a file with extension .txt.
